The following are comma-separated files containing XY positions of
either antennas or stations in the three SKA1 arrays. The file names
contain descriptors indicating which part of the configurations is
contained in the file (core, arms, precursor positions). SKA1-survey and
SKA1-low share the same zero point, the position of ASKAP antenna 1.


SKA1-survey
SKA1-survey_config_baseline_design_arm_antennas_2013apr30.csv
SKA1-survey_config_baseline_design_core_antennas_2013apr30.csv
SKA-survey_config_baseline_design_ASKAP_antennas_2013apr30.csv

SKA1-low
SKA-low_config_baseline_design_arm_stations_2013apr30.csv
SKA-low_config_baseline_design_core_stations_2013apr30.csv

SKA1-mid
SKA-mid_config_baseline_design_MeerKAT_antennas_2013apr30.csv
SKA-mid_config_baseline_design_arm_antennas_2013apr30.csv
SKA-mid_config_baseline_design_core_antennas_2013apr30.csv


